library(shiny)
library(httpuv)
library(rsconnect)

ui <- fluidPage(
        pageWithSidebar(
        headerPanel("Network Visualizations"),

    sidebarPanel(
        radioButtons("IndGroDyn", label = h3("Individual-level, group-level networks or dynamic networks?"), 
                       choices = c("Individual-level networks","Group-level networks", "Dynamic Networks"), selected = "Individual-level networks"),
        conditionalPanel(condition = "input.IndGroDyn == 'Individual-level networks'",
                     selectInput("IndNetwork", "Please select individual-level network",
                                 choices = c("Participant ID # 2", "Participant ID # 4","Participant ID # 6", "Participant ID # 8","Participant ID # 9", "Participant ID # 10",
                                             "Participant ID # 12", "Participant ID # 18","Participant ID # 19", "Participant ID # 20","Participant ID # 22", "Participant ID # 23",
                                             "Participant ID # 24", "Participant ID # 25","Participant ID # 26", "Participant ID # 28","Participant ID # 29", "Participant ID # 30",
                                             "Participant ID # 31", "Participant ID # 32","Participant ID # 35", "Participant ID # 36", "Participant ID # 37","Participant ID # 38",
                                             "Participant ID # 42", "Participant ID # 44"))),
        conditionalPanel(condition = "input.IndGroDyn == 'Group-level networks'",
                     selectInput("GroupNetwork", "Please select group-level network",
                                 choices = c("Total Sample", "Personality Profile Anxiety Sensitivity", "Personality Profile Negative Thinking",
                                             "Personality Profile Impulsivity", "Personality Profile Sensation Seeking",
                                             "Males", "Females"))),
        conditionalPanel(condition = "input.IndGroDyn == 'Dynamic Networks'",
                     selectInput("DynNetworks", "Please select participant",
                                 choices = c("Participant ID # 2", "Participant ID # 4","Participant ID # 9", "Participant ID # 18","Participant ID # 22",
                                             "Participant ID # 24", "Participant ID # 25","Participant ID # 26", "Participant ID # 28","Participant ID # 29", "Participant ID # 30",
                                             "Participant ID # 31", "Participant ID # 35","Participant ID # 42", "Participant ID # 44")))),
mainPanel(
    uiOutput("video"),imageOutput("NetworkImage")
    )
))  


server <- function(input, output) {
    output$NetworkImage <- renderImage({
        if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 2"){
            list(src = "Network 2.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 4"){
            list(src = "Network 4.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 6"){
            list(src = "Network 6.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 8"){
            list(src = "Network 8.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 9"){
            list(src = "Network 9.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 10"){
            list(src = "Network 10.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 12"){
            list(src = "Network 12.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 18"){
            list(src = "Network 18.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 19"){
            list(src = "Network 19.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 20"){
            list(src = "Network 20.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 22"){
            list(src = "Network 22.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 23"){
            list(src = "Network 23.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 24"){
            list(src = "Network 24.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 25"){
            list(src = "Network 25.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 26"){
            list(src = "Network 26.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 28"){
            list(src = "Network 28.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 29"){
            list(src = "Network 29.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 30"){
            list(src = "Network 30.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 31"){
            list(src = "Network 31.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 32"){
            list(src = "Network 32.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 35"){
            list(src = "Network 35.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 36"){
            list(src = "Network 36.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 37"){
            list(src = "Network 37.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 38"){
            list(src = "Network 38.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 42"){
            list(src = "Network 42.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Individual-level networks" & input$IndNetwork == "Participant ID # 44"){
            list(src = "Network 44.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Group-level networks" & input$GroupNetwork == "Total Sample"){
            list(src = "Summary_plot.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Group-level networks" & input$GroupNetwork == "Personality Profile Anxiety Sensitivity"){
          list(src = "Network Profile AS.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Group-level networks" & input$GroupNetwork == "Personality Profile Sensation Seeking"){
          list(src = "Network Profile SS.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Group-level networks" & input$GroupNetwork == "Personality Profile Impulsivity"){
          list(src = "Network Profile IMP.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Group-level networks" & input$GroupNetwork == "Personality Profile Negative Thinking"){
          list(src = "Network Profile NT.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Group-level networks" & input$GroupNetwork == "Males"){
          list(src = "Network Males.jpeg", height = 500, width = 500)
        }else if(input$IndGroDyn == "Group-level networks" & input$GroupNetwork == "Females"){
            list(src = "Network Females.jpeg", height = 500, width = 500)}
    },deleteFile = F)
    
    output$video <- renderUI({
        if(input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 2"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_2.mp4", type = "video/mp4")
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 4"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_4.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 9"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_9.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 18"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_18.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 22"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_22.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 24"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_24.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 25"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_25.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 26"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_26.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 28"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_28.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 29"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_29.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 30"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_30.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 31"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_31.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 35"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_35.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 42"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_42.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)
        }else if (input$IndGroDyn == "Dynamic Networks" & input$DynNetworks == "Participant ID # 44"){
            tags$video(width="900", height="700", controls="", 
                       src = "Dynamic_Networks_Video_Participant_44.mp4", type = "video/mp4", autoplay = TRUE, controls = TRUE)}
    })
}

# Run the application 
deployApp()
